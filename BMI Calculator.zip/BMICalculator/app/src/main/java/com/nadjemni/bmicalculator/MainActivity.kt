package com.nadjemni.bmicalculator

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import android.support.design.widget.Snackbar

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        calculateBtn.setOnClickListener {
            if(heightEDTX.text.isNotEmpty() && weightEDTX.text.isNotEmpty()) {
                val weight=weightEDTX.text.toString().toDouble()
                val height=heightEDTX.text.toString().toInt()
                if(weight>0&&weight<600&&height>=50&&height<2.5){
                val intent = Intent(this@MainActivity,  ResultActivity::class.java)
                intent.putExtra("bmi", calculateBMI(weight,height))
                startActivity(intent)
                }else{
                showErrorSnack("Incorrect Values")
                }
            }else{
                showErrorSnack("A filed is missing")
            }
        }
    }

    private fun showErrorSnack(errorMsg:String) {
        val snackbar = Snackbar.make(view, "error : $errorMsg !",Snackbar.LENGTH_LONG)
        snackbar.view.setBackgroundColor(R.color.colorRed)
        val textView = snackbar.view.findViewById(android.support.design.R.id.snackbar_text) as TextView
        textView.setTextColor(Color.WHITE)
        textView.textSize = 20f
        snackbar.show()
    }

   private fun calculateBMI(weight:Double,height:Int)=(weight/((height/100)*(height/100)))

}
